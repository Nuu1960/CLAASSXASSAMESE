package com.example

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.Chapter
import com.example.data.ChapterRepository
import com.example.data.QuestionAnswer
import com.example.data.WordMeaning
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Intercept uncaught exceptions and log them with high priority to logcat
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            android.util.Log.e("CRASH_LOGGER", "FATAL CRASH in thread [${thread.name}]: ${throwable.message}", throwable)
            defaultHandler?.uncaughtException(thread, throwable)
        }

        enableEdgeToEdge()
        
        // Initialize AdMob Mobile Ads SDK safely if supported on this device/environment
        try {
            if (com.example.api.AdMobManager.isAdsSupported(this)) {
                com.google.android.gms.ads.MobileAds.initialize(this) {
                    runOnUiThread {
                        com.example.api.AdMobManager.loadInterstitial(this)
                    }
                }
            } else {
                android.util.Log.d("MainActivity", "AdMob is not supported on this device/environment. Bypassing initialization.")
            }
        } catch (e: Throwable) {
            android.util.Log.e("MainActivity", "Failed to initialize MobileAds: ${e.message}", e)
        }

        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen() {
    val context = LocalContext.current
    val activity = remember(context) {
        var curr = context
        while (curr is android.content.ContextWrapper) {
            if (curr is android.app.Activity) break
            curr = curr.baseContext
        }
        curr as? android.app.Activity
    }
    val scope = rememberCoroutineScope()
    
    // Preferences persistence
    val sharedPrefs = remember { context.getSharedPreferences("MilAssamesePrefs", Context.MODE_PRIVATE) }
    
    // State lists
    val bookmarkedQuestionIds = remember {
        mutableStateOf(sharedPrefs.getStringSet("bookmarks", emptySet()) ?: emptySet())
    }
    val readChapterIds = remember {
        mutableStateOf(sharedPrefs.getStringSet("progress", emptySet())?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet())
    }
    
    // Selected states
    var selectedChapter by remember { mutableStateOf<Chapter?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    
    // Filters
    val typeFilters = listOf("সকল", "পদ্য", "গদ্য")
    var selectedTypeFilter by remember { mutableStateOf("সকল") }
    
    val groupFilters = listOf("সকল", "Group-A", "Group-B")
    var selectedGroupFilter by remember { mutableStateOf("সকল") }
    
    // Global text sizing multiplier & Ads preference
    var fontSizeMultiplier by remember { mutableStateOf(1.0f) }
    var disableAds by remember { mutableStateOf(sharedPrefs.getBoolean("disable_ads", com.example.BuildConfig.DEBUG)) }
    var showFontDialog by remember { mutableStateOf(false) }
    
    // Save functionality helpers
    val toggleBookmark: (String) -> Unit = { id ->
        val current = bookmarkedQuestionIds.value.toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
            Toast.makeText(context, "বুকমাৰ্ক আঁতৰোৱা হ'ল", Toast.LENGTH_SHORT).show()
        } else {
            current.add(id)
            Toast.makeText(context, "প্ৰশ্নটো বুকমাৰ্ক কৰা হ'ল", Toast.LENGTH_SHORT).show()
        }
        bookmarkedQuestionIds.value = current
        sharedPrefs.edit().putStringSet("bookmarks", current).apply()
    }
    
    val toggleRead: (Int) -> Unit = { id ->
        val current = readChapterIds.value.toMutableSet()
        if (current.contains(id)) {
            current.remove(id)
        } else {
            current.add(id)
        }
        readChapterIds.value = current
        sharedPrefs.edit().putStringSet("progress", current.map { it.toString() }.toSet()).apply()
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = if (selectedChapter != null) selectedChapter!!.title else "Class 10 MIL Assamese",
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                },
                navigationIcon = {
                    if (selectedChapter != null) {
                        IconButton(onClick = { selectedChapter = null }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.Menu,
                            contentDescription = "App Logo",
                            modifier = Modifier.padding(start = 16.dp),
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { showFontDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Fonts",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (showFontDialog) {
                FontSizeSelectorDialog(
                    multiplier = fontSizeMultiplier,
                    onMultiplierChange = { fontSizeMultiplier = it },
                    disableAds = disableAds,
                    onDisableAdsChange = {
                        disableAds = it
                        sharedPrefs.edit().putBoolean("disable_ads", it).apply()
                    },
                    onClearProgress = {
                        readChapterIds.value = emptySet()
                        sharedPrefs.edit().remove("progress").apply()
                        Toast.makeText(context, "অধ্যয়নৰ অগ্ৰগতি মচা হ'ল।", Toast.LENGTH_SHORT).show()
                    },
                    onClearBookmarks = {
                        bookmarkedQuestionIds.value = emptySet()
                        sharedPrefs.edit().remove("bookmarks").apply()
                        Toast.makeText(context, "বুকমাৰ্কসমূহ মচা হ'ল।", Toast.LENGTH_SHORT).show()
                    },
                    onDismiss = { showFontDialog = false }
                )
            }
            
            Crossfade(targetState = selectedChapter, label = "ScreenTransition") { chapter ->
                if (chapter == null) {
                    // Home Screen Layout
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Hero Header with Rhino & Butterfly decorative graphic
                        HeroHeaderCard()
                        
                        // Statistics Row
                        StatsSection(
                            totalChapters = ChapterRepository.chapters.size,
                            completedCount = readChapterIds.value.size,
                            bookmarksCount = bookmarkedQuestionIds.value.size,
                            onShowBookmarks = {
                                Toast.makeText(context, "তললৈ যাওক আৰু বুকমাৰ্কসমূহ পঢ়ক।", Toast.LENGTH_LONG).show()
                            }
                        )
                        
                        // Search Bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            placeholder = { Text("পাঠ বা প্ৰশ্নৰ কীৱৰ্ড সন্ধান কৰক...") },
                            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp)
                        )
                        
                        // Filters - Category & Group
                        FilterTabs(
                            title = "বিভাগ অনুসৰি ফিল্টাৰ:",
                            filters = typeFilters,
                            selectedFilter = selectedTypeFilter,
                            onFilterSelect = { selectedTypeFilter = it }
                        )

                        FilterTabs(
                            title = "গ্ৰুপ অনুসৰি ফিল্টাৰ:",
                            filters = groupFilters,
                            selectedFilter = selectedGroupFilter,
                            onFilterSelect = { selectedGroupFilter = it }
                        )
                        
                        // All bookmarked questions preview box if any
                        if (bookmarkedQuestionIds.value.isNotEmpty()) {
                            BookmarkedQuestionsHighlight(
                                savedIds = bookmarkedQuestionIds.value,
                                onRemove = { toggleBookmark(it) },
                                fontSizeMultiplier = fontSizeMultiplier
                            )
                        }

                        // Chapter List Divider
                        Text(
                            text = "আটাইকেইটা কোৰ্স আৰু পাঠ্যক্ৰম",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        // Filtered chapters list
                        val filteredList = ChapterRepository.chapters.filter { ch ->
                            val matchSearch = ch.title.contains(searchQuery, ignoreCase = true) ||
                                    ch.author.contains(searchQuery, ignoreCase = true) ||
                                    ch.questions.any { it.question.contains(searchQuery, ignoreCase = true) }
                            val matchType = selectedTypeFilter == "সকল" || ch.type == selectedTypeFilter
                            val matchGroup = selectedGroupFilter == "সকল" || ch.group == selectedGroupFilter
                            matchSearch && matchType && matchGroup
                        }

                        if (filteredList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "কোনো পাঠ বিচাৰি পোৱা নগ'ল!",
                                    textAlign = TextAlign.Center,
                                    color = Color.Gray
                                )
                            }
                        } else {
                            filteredList.forEach { ch ->
                                ChapterCardItem(
                                    chapter = ch,
                                    isRead = readChapterIds.value.contains(ch.id),
                                    onReadToggle = { toggleRead(ch.id) },
                                    onClick = {
                                        if (activity != null) {
                                            com.example.api.AdMobManager.showInterstitial(activity) {
                                                selectedChapter = ch
                                            }
                                        } else {
                                            selectedChapter = ch
                                        }
                                    }
                                )
                            }
                        }
                        
                        // Display AdMob Banner advertisement
                        Spacer(modifier = Modifier.height(16.dp))
                        com.example.api.AdmobBanner(modifier = Modifier.padding(vertical = 8.dp))
                        
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                } else {
                    // Chapter Details View
                    ChapterDetailsScreen(
                        chapter = chapter,
                        isBookmarked = { qId -> bookmarkedQuestionIds.value.contains(qId) },
                        onBookmarkToggle = { toggleBookmark(it) },
                        isRead = readChapterIds.value.contains(chapter.id),
                        onReadToggle = { toggleRead(chapter.id) },
                        fontSizeMultiplier = fontSizeMultiplier,
                        onBack = { selectedChapter = null }
                    )
                }
            }
        }
    }
}

@Composable
fun HeroHeaderCard() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    // Draw continuous aesthetic organic waves
                    val grad = Brush.linearGradient(
                        colors = listOf(Color(0xFF1E5631), Color(0xFF0F2E1A)),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height)
                    )
                    drawRect(brush = grad)
                    
                    // Draw decorative gold wavy line at the bottom
                    val path = Path().apply {
                        moveTo(0f, size.height * 0.8f)
                        quadraticTo(
                            size.width * 0.25f, size.height * 0.65f,
                            size.width * 0.5f, size.height * 0.8f
                        )
                        quadraticTo(
                            size.width * 0.75f, size.height * 0.95f,
                            size.width, size.height * 0.8f
                        )
                    }
                    drawPath(
                        path = path,
                        color = Color(0xFFF1C40F),
                        style = Stroke(width = 4f)
                    )
                }
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Badge(
                            containerColor = Color(0xFFF1C40F),
                            contentColor = Color.Black,
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Text("দশম শ্ৰেণী", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        
                        Text(
                            text = "অসমীয়া সাহিত্য চয়নিকা",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 22.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "দ্বিতীয় ভাগ  (MIL Guide Book)",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 14.sp
                        )
                    }
                    
                    // Decorative butterfly path drawing using custom Canvas
                    Canvas(modifier = Modifier.size(50.dp)) {
                        val butterflyPath = Path().apply {
                            moveTo(size.width / 2, size.height * 0.8f)
                            // Left wing
                            cubicTo(
                                size.width * 0.1f, size.height * 0.6f,
                                size.width * 0.1f, size.height * 0.1f,
                                size.width / 2, size.height * 0.4f
                            )
                            // Right wing
                            cubicTo(
                                size.width * 0.9f, size.height * 0.1f,
                                size.width * 0.9f, size.height * 0.6f,
                                size.width / 2, size.height * 0.8f
                            )
                        }
                        drawPath(path = butterflyPath, color = Color(0xFFF1C40F))
                        
                        // Butterfly body lines
                        drawLine(
                            color = Color.White,
                            start = Offset(size.width / 2, size.height * 0.2f),
                            end = Offset(size.width / 2, size.height * 0.9f),
                            strokeWidth = 3f
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "ভাৰতীয় বৰ্ড পৰীক্ষাৰ (SEBA) বাবে অনুমোদিত আটাইকেইটা অধ্যায়ৰ প্ৰশ্ন আৰু নিখুঁত উত্তৰ ইয়াত সৰলকৈ দিয়া হৈছে।",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun StatsSection(
    totalChapters: Int,
    completedCount: Int,
    bookmarksCount: Int,
    onShowBookmarks: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Card(
            modifier = Modifier.weight(1f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "$totalChapters", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Text(text = "মুঠ পাঠ্যক্ৰম", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        }
        
        Card(
            modifier = Modifier.weight(1f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(text = "$completedCount", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.primary)
                Text(text = "সমাপ্ত পাঠ", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        }

        Card(
            modifier = Modifier
                .weight(1f)
                .clickable { onShowBookmarks() },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Favorite, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "$bookmarksCount", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                Text(text = "সংৰক্ষিত প্ৰশ্ন", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun FilterTabs(
    title: String,
    filters: List<String>,
    selectedFilter: String,
    onFilterSelect: (String) -> Unit
) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { filter ->
                val isSelected = filter == selectedFilter
                FilterChip(
                    selected = isSelected,
                    onClick = { onFilterSelect(filter) },
                    label = { Text(filter, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }
    }
}

@Composable
fun ChapterCardItem(
    chapter: Chapter,
    isRead: Boolean,
    onReadToggle: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circle Badge displaying type / index
            Box(
                modifier = Modifier
                    .size(45.dp)
                    .clip(CircleShape)
                    .background(
                        if (chapter.type == "পদ্য") MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                        else MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (chapter.type == "পদ্য") "প" else "গ",
                    fontWeight = FontWeight.Bold,
                    color = if (chapter.type == "পদ্য") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                    fontSize = 16.sp
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "পাঠ ${chapter.id}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "•  ${chapter.group}",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                
                Text(
                    text = chapter.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                )
                
                Text(
                    text = "লেখক/কবি গৰাকী: " + chapter.author,
                    fontSize = 12.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            Checkbox(
                checked = isRead,
                onCheckedChange = { onReadToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = MaterialTheme.colorScheme.primary,
                    uncheckedColor = Color.Gray
                )
            )
        }
    }
}

@Composable
fun BookmarkedQuestionsHighlight(
    savedIds: Set<String>,
    onRemove: (String) -> Unit,
    fontSizeMultiplier: Float
) {
    // Collect bookmarked questions
    val savedQuestions = remember(savedIds) {
        ChapterRepository.chapters.flatMap { ch ->
            ch.questions.filter { savedIds.contains(it.id) }.map { q -> Pair(ch.title, q) }
        }
    }
    
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Starred Highlight",
                        tint = Color.Red,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "মোৰ প্ৰিয় প্ৰশ্নসমূহ (${savedQuestions.size})",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )
                }
                
                TextButton(onClick = { isExpanded = !isExpanded }) {
                    Text(if (isExpanded) "সংকোচন" else "পঢ়ক")
                }
            }
            
            if (isExpanded) {
                Spacer(modifier = Modifier.height(8.dp))
                
                savedQuestions.forEach { (chapterName, q) ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = chapterName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                IconButton(
                                    onClick = { onRemove(q.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Favorite,
                                        contentDescription = "Remove Bookmark",
                                        tint = Color.Red,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "প্ৰশ্ন: " + q.question,
                                fontWeight = FontWeight.Bold,
                                fontSize = (14 * fontSizeMultiplier).sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "উত্তৰ: " + q.answer,
                                fontSize = (13 * fontSizeMultiplier).sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                                lineHeight = (18 * fontSizeMultiplier).sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterDetailsScreen(
    chapter: Chapter,
    isBookmarked: (String) -> Boolean,
    onBookmarkToggle: (String) -> Unit,
    isRead: Boolean,
    onReadToggle: () -> Unit,
    fontSizeMultiplier: Float,
    onBack: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabLabels = listOf("প্ৰশ্নোত্তৰ", "কবি/লেখক পৰিচয়", "শব্দাৰ্থ")
    
    // Internal selected Q&A search filtering
    var qaSearchQuery by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        // Tab Header
        ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 16.dp,
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ) {
            tabLabels.forEachIndexed { index, label ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                )
            }
        }
        
        Spacer(modifier = Modifier.height(8.dp))
        
        // Progress status toggle inside details
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "শ্ৰেণী: ${chapter.group} | ভাগ: ${chapter.type}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
            
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onReadToggle() }
            ) {
                Text(
                    text = if (isRead) "মই এই পাঠটো পঢ়িছোঁ" else "পাঠটো সম্পূৰ্ণ কৰা বুলি চিহ্নিত কৰক",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isRead) MaterialTheme.colorScheme.primary else Color.Gray,
                    modifier = Modifier.padding(end = 4.dp)
                )
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = if (isRead) MaterialTheme.colorScheme.primary else Color.Transparent,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
        
        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f), modifier = Modifier.padding(horizontal = 16.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> {
                    // Q&A Tab Screen
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Embedded Search inside selected Q&As
                        OutlinedTextField(
                            value = qaSearchQuery,
                            onValueChange = { qaSearchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            placeholder = { Text("প্ৰশ্ন বা উত্তৰৰ অনুসন্ধান কৰক...") },
                            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search QAs") },
                            shape = CircleShape,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White
                            )
                        )
                        
                        val filteredQAs = chapter.questions.filter {
                            it.question.contains(qaSearchQuery, ignoreCase = true) ||
                                    it.answer.contains(qaSearchQuery, ignoreCase = true)
                        }
                        
                        if (filteredQAs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("কোনো প্ৰশ্ন পোৱা নগ'ল!", color = Color.Gray)
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 16.dp)
                            ) {
                                items(filteredQAs) { qa ->
                                    val isStarred = isBookmarked(qa.id)
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (qa.isGrammar) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)
                                                             else MaterialTheme.colorScheme.surface
                                        ),
                                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f)),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.Top
                                            ) {
                                                if (qa.isGrammar) {
                                                    Badge(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.8f)) {
                                                        Text("ব্যাকৰণ / ভাষা", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                                    }
                                                } else {
                                                    Spacer(modifier = Modifier.width(1.dp))
                                                }
                                                
                                                IconButton(
                                                    onClick = { onBookmarkToggle(qa.id) },
                                                    modifier = Modifier.size(30.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (isStarred) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                                                        contentDescription = "Bookmark question",
                                                        tint = if (isStarred) Color.Red else Color.LightGray
                                                    )
                                                }
                                            }
                                            
                                            Text(
                                                text = "প্ৰশ্ন: " + qa.question,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = (15 * fontSizeMultiplier).sp,
                                                lineHeight = (20 * fontSizeMultiplier).sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "উত্তৰ: " + qa.answer,
                                                fontSize = (14 * fontSizeMultiplier).sp,
                                                lineHeight = (20 * fontSizeMultiplier).sp,
                                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f)
                                            )
                                        }
                                    }
                                }
                                item { Spacer(modifier = Modifier.height(32.dp)) }
                            }
                        }
                    }
                }
                1 -> {
                    // Author & Bio Tab Screen
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = "কবি/লেখক পৰিচয়:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = chapter.author,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        
                        HorizontalDivider(color = Color.LightGray, modifier = Modifier.padding(vertical = 8.dp))
                        
                        Text(
                            text = chapter.aboutAuthor,
                            fontSize = (14 * fontSizeMultiplier).sp,
                            lineHeight = (22 * fontSizeMultiplier).sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                        )
                        
                        Spacer(modifier = Modifier.height(20.dp))
                        
                        Text(
                            text = "এই পাঠৰ মূল অৰ্থ আৰু সাৰাংশ:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = chapter.summary,
                            fontSize = (14 * fontSizeMultiplier).sp,
                            lineHeight = (22 * fontSizeMultiplier).sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Spacer(modifier = Modifier.height(64.dp))
                    }
                }
                2 -> {
                    // Word Meanings Tab Screen
                    if (chapter.vocabulary.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("এই পাঠৰ কোনো কঠিন শব্দৰ তালিকা নাই।", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 16.dp)
                        ) {
                            item {
                                Text(
                                    text = "শব্দাৰ্থ আৰু টোকা:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    modifier = Modifier.padding(vertical = 12.dp),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            items(chapter.vocabulary) { voc ->
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = voc.word,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = (16 * fontSizeMultiplier).sp,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.weight(1f)
                                        )
                                        
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                            contentDescription = null,
                                            tint = Color.LightGray,
                                            modifier = Modifier.padding(horizontal = 8.dp)
                                        )
                                        
                                        Text(
                                            text = voc.meaning,
                                            fontSize = (14 * fontSizeMultiplier).sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                                            modifier = Modifier.weight(2f),
                                            lineHeight = (18 * fontSizeMultiplier).sp
                                        )
                                    }
                                }
                            }
                            item { Spacer(modifier = Modifier.height(48.dp)) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FontSizeSelectorDialog(
    multiplier: Float,
    onMultiplierChange: (Float) -> Unit,
    disableAds: Boolean,
    onDisableAdsChange: (Boolean) -> Unit,
    onClearProgress: () -> Unit,
    onClearBookmarks: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "এপ্লিকেচন ছেটিংস",
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                // Section 1: Font Size
                Text(
                    text = "আখৰৰ আকাৰ ঠিক কৰক",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Start)
                )
                
                // Real-time preview
                Text(
                    text = "অসমীয়া চয়নিকা Guide",
                    fontSize = (16 * multiplier).sp,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
                
                Slider(
                    value = multiplier,
                    onValueChange = onMultiplierChange,
                    valueRange = 0.8f..1.6f,
                    modifier = Modifier.fillMaxWidth()
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("সৰু", fontSize = 11.sp, color = Color.Gray)
                    Text("সাধাৰণ", fontSize = 11.sp, color = Color.Gray)
                    Text("ডাঙৰ", fontSize = 11.sp, color = Color.Gray)
                }
                
                HorizontalDivider(
                    color = Color.LightGray.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = 16.dp)
                )
                
                // Section 2: Ad Control
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "বিজ্ঞাপন বন্ধ কৰক",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "প্ৰদূষণমুক্ত পঢ়াৰ বাবে বিজ্ঞাপন ল'ড কৰা বন্ধ কৰিব পাৰে",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            lineHeight = 14.sp
                        )
                    }
                    Switch(
                        checked = disableAds,
                        onCheckedChange = onDisableAdsChange,
                        thumbContent = {
                            if (disableAds) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize)
                                )
                            }
                        }
                    )
                }
                
                HorizontalDivider(
                    color = Color.LightGray.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = 16.dp)
                )
                
                // Section 3: Data Management
                Text(
                    text = "তথ্য পৰিচালনা",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onClearProgress,
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("প্ৰগতি মচুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    
                    OutlinedButton(
                        onClick = onClearBookmarks,
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("বুকমাৰ্ক মচুন", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("হৈছে", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
