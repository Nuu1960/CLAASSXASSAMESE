package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ForestGreen80 = Color(0xFF27AE60)
val Gold80 = Color(0xFFF1C40F)
val SoftCreamDark = Color(0xFF1A252C)

val ForestGreen40 = Color(0xFF1E5631)
val Gold40 = Color(0xFFD4AF37)
val SoftCreamLight = Color(0xFFFDFDF6)

val MintAccent = Color(0xFFE8F5E9)
val CharcoalDark = Color(0xFF1C2833)
val WarmText = Color(0xFF2C3E50)
val LightGrayLine = Color(0xFFE0E0E0)
val GoldenSun = Color(0xFFFFD700)
val DarkGreenSurface = Color(0xFF0F2E1A)
