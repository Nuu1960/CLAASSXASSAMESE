package com.example.api

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.BuildConfig
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

object AdMobManager {
    private const val TAG = "AdMobManager"

    // Ad Unit IDs (read from BuildConfig populated from .env)
    private val REAL_BANNER_ID = BuildConfig.ADMOB_BANNER_ID
    private val REAL_INTERSTITIAL_ID = BuildConfig.ADMOB_INTERSTITIAL_ID

    // Test Ad Unit IDs provided by Google
    private const val TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
    private const val TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"

    // Decide which ID to use based on BuildConfig.DEBUG
    val bannerAdUnitId: String
        get() = if (BuildConfig.DEBUG) TEST_BANNER_ID else REAL_BANNER_ID

    val interstitialAdUnitId: String
        get() = if (BuildConfig.DEBUG) TEST_INTERSTITIAL_ID else REAL_INTERSTITIAL_ID

    private var mInterstitialAd: InterstitialAd? = null
    private var isAdLoading = false

    /**
     * Check if AdMob environment is supported.
     * Returns false on emulators, virtual environments, or devices without Google Play Services
     * to avoid WebView initialization crashes or GMS exceptions.
     */
    fun isAdsSupported(context: Context): Boolean {
        try {
            // First check user preference, default to disabling ads on debug builds for 100% stability.
            val prefs = context.getSharedPreferences("MilAssamesePrefs", Context.MODE_PRIVATE)
            val isAdsDisabled = prefs.getBoolean("disable_ads", com.example.BuildConfig.DEBUG)
            if (isAdsDisabled) {
                Log.d(TAG, "Ads are disabled via settings (disable_ads = true).")
                return false
            }

            // Disable ads if running in the AI Studio environment or any default testing/example package
            val pkgName = context.packageName ?: ""
            if (pkgName.contains("aistudio") || pkgName.contains("example")) {
                Log.d(TAG, "Ads are disabled on sandbox (AI Studio) or example packages ($pkgName).")
                return false
            }

            // Disable ads in virtual environment / emulator / headless environments to prevent crashes
            val buildFingerprint = android.os.Build.FINGERPRINT ?: ""
            val buildModel = android.os.Build.MODEL ?: ""
            val buildManufacturer = android.os.Build.MANUFACTURER ?: ""
            val buildBrand = android.os.Build.BRAND ?: ""
            val buildDevice = android.os.Build.DEVICE ?: ""
            val buildProduct = android.os.Build.PRODUCT ?: ""
            val buildHardware = android.os.Build.HARDWARE ?: ""

            val lowercaseModel = buildModel.lowercase()
            val lowercaseFingerprint = buildFingerprint.lowercase()

            val isEmulator = (buildFingerprint.startsWith("generic")
                    || buildFingerprint.startsWith("unknown")
                    || buildModel.contains("google_sdk")
                    || buildModel.contains("Emulator")
                    || buildModel.contains("Android SDK built for x86")
                    || buildManufacturer.contains("Genymotion")
                    || (buildBrand.startsWith("generic") && buildDevice.startsWith("generic"))
                    || "google_sdk" == buildProduct
                    || buildHardware.contains("goldfish")
                    || buildHardware.contains("ranchu")
                    || lowercaseModel.contains("emulator")
                    || lowercaseModel.contains("virtual")
                    || lowercaseFingerprint.contains("vbox")
                    || lowercaseFingerprint.contains("sdk")
                    || lowercaseFingerprint.contains("test-keys")
                    || lowercaseFingerprint.contains("genymotion")
                    || lowercaseFingerprint.contains("google_sdk"))

            if (isEmulator) {
                Log.d(TAG, "AdMob is disabled on Emulator/Virtual device.")
                return false
            }

            // Also check if Google Play Services package is present
            context.packageManager.getPackageInfo("com.google.android.gms", 0)
        } catch (e: Throwable) {
            Log.d(TAG, "AdMob is disabled (GMS package not found or exception: ${e.message}).")
            return false
        }
        return true
    }

    /**
     * Load an interstitial ad pre-emptively so it is ready when needed with full exception safety.
     */
    fun loadInterstitial(context: Context) {
        try {
            if (!isAdsSupported(context)) {
                Log.d(TAG, "loadInterstitial: skipped since Google Ads are not supported.")
                return
            }
            if (mInterstitialAd != null || isAdLoading) return

            isAdLoading = true
            val adRequest = AdRequest.Builder().build()
            val adUnitId = interstitialAdUnitId

            Log.d(TAG, "Loading interstitial ad with ID: $adUnitId")
            InterstitialAd.load(
                context.applicationContext,
                adUnitId,
                adRequest,
                object : InterstitialAdLoadCallback() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        Log.e(TAG, "Ad failed to load: ${adError.message}")
                        mInterstitialAd = null
                        isAdLoading = false
                    }

                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        Log.d(TAG, "Ad loaded successfully.")
                        mInterstitialAd = interstitialAd
                        isAdLoading = false
                    }
                }
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Exception in loadInterstitial: ${t.message}", t)
            isAdLoading = false
        }
    }

    /**
     * Show the interstitial ad if loaded, or execute the callback immediately if not loaded.
     * Prevents crashes on any error.
     */
    fun showInterstitial(activity: Activity, onAdClosed: () -> Unit) {
        try {
            if (!isAdsSupported(activity)) {
                Log.d(TAG, "showInterstitial: skipped since Google Ads are not supported.")
                onAdClosed()
                return
            }
            val interstitialAd = mInterstitialAd
            if (interstitialAd != null) {
                interstitialAd.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                    override fun onAdDismissedFullScreenContent() {
                        Log.d(TAG, "Ad was dismissed.")
                        mInterstitialAd = null
                        // Load the next ad pre-emptively
                        loadInterstitial(activity)
                        onAdClosed()
                    }

                    override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                        Log.e(TAG, "Ad failed to show: ${adError.message}")
                        mInterstitialAd = null
                        onAdClosed()
                    }

                    override fun onAdShowedFullScreenContent() {
                        Log.d(TAG, "Ad showed full screen content.")
                    }
                }
                interstitialAd.show(activity)
            } else {
                Log.d(TAG, "Interstitial ad was not ready yet.")
                // Try to load one for next time
                loadInterstitial(activity)
                onAdClosed()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Exception in showInterstitial: ${t.message}", t)
            onAdClosed()
        }
    }
}

@Composable
fun AdmobBanner(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val isSupported = remember(context) { AdMobManager.isAdsSupported(context) }

    if (!isSupported) {
        // Fallback transparent zero-height space when AdMob is not supported
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(0.dp)
        )
        return
    }

    val adView = remember {
        try {
            AdView(context).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = AdMobManager.bannerAdUnitId
            }
        } catch (t: Throwable) {
            Log.e("AdMobManager", "Failed to create AdView in remember block: ${t.message}", t)
            null
        }
    }

    if (adView != null) {
        // Load the ad EXACTLY ONCE when the adView is first remembered
        LaunchedEffect(adView) {
            try {
                adView.loadAd(AdRequest.Builder().build())
            } catch (t: Throwable) {
                Log.e("AdMobManager", "Exception in loadAd inside LaunchedEffect: ${t.message}", t)
            }
        }

        val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner, adView) {
            val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
                try {
                    when (event) {
                        androidx.lifecycle.Lifecycle.Event.ON_RESUME -> adView.resume()
                        androidx.lifecycle.Lifecycle.Event.ON_PAUSE -> adView.pause()
                        androidx.lifecycle.Lifecycle.Event.ON_DESTROY -> adView.destroy()
                        else -> {}
                    }
                } catch (t: Throwable) {
                    Log.e("AdMobManager", "Exception in AdView lifecycle: ${t.message}", t)
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose {
                try {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                    adView.destroy()
                } catch (t: Throwable) {
                    Log.e("AdMobManager", "Exception inside onDispose of AdView: ${t.message}", t)
                }
            }
        }

        AndroidView(
            modifier = modifier.fillMaxWidth(),
            factory = { adView },
            update = { /* Do NOTHING here to prevent infinite recomposition loops! */ }
        )
    } else {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .height(50.dp)
                .background(Color.Transparent)
        )
    }
}
